# Plataforma Vini (clean)

## Rodar local
1. npm i
2. crie `.env.local` com:
   VITE_SUPABASE_URL=
   VITE_SUPABASE_ANON_KEY=
3. npm run dev

## Deploy Vercel
- Configure as variáveis:
  - VITE_SUPABASE_URL
  - VITE_SUPABASE_ANON_KEY
- Deploy direto do Git.

## Fluxo
- `/` público (Home estilizada)
- `/login` página de login (Supabase)
- `/dashboard` protegido (renderiza Home por enquanto — troque pelo que quiser)
